let usersArr = [
  {
    name: "Ravi",    
    ImageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRuFDNx_K5JPpfn3mzFjNX0aYmSQ448R1SdwskxWW1V3g&s=10",
  },
  {
    name: "Kishan",   
    Imageurl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQuCCRNL5epJON3GJzlsss3eVbG5-MNNW_Pxj-QyRxOHw&s=10",
  },
  {
    name: "Karan",
   
    Imageurl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQVGrpoOZWWWkW3bbnzgBMVt-2kX9d0iDgcvl9LO4nUgQ&s=10",
  },
  {
    name: "Johar",
    
   Imageurl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRf2C2DtiJc2VlSQYj0H9XRaoNQvG9WJIYZGbkWGDEfzA&s=10",
  },
];

 
let main = document.querySelector("main");
let cards =document.querySelector(".cards");


  usersArr.forEach((val, index) => {
    cards.innerHTML += `<div class="user-card">
                <div class="img">
                    <img src="${val.Imageurl}" alt="">
                </div>

                <div class="text">
                    <h1>${val.name}</h1>
                   
                </div>

                <div class="btns">
                    <button id="edit">Edit</button>
                    <button onclick="deleteFn(${index})" id="del">Delete</button>
                </div>
            </div>`;
  });






  
  